import json
import os
import boto3
from botocore.exceptions import ClientError
from typing import Dict, Any

def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda function for user authentication using AWS Cognito
    Supports both CPF-only authentication (User group) and email/password (Admin group)
    """
    print(f"Received event: {json.dumps(event)}")

    # Handle CORS preflight requests
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST',
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                'Content-Type': 'application/json'
            },
            'body': ''
        }

    try:
        # Parse request body
        body = json.loads(event.get('body', '{}'))
        cpf = body.get('cpf')
        email = body.get('email')
        password = body.get('password')

        # Get Cognito configuration from environment
        user_pool_id = os.environ.get('COGNITO_USER_POOL_ID')
        client_id = os.environ.get('COGNITO_CLIENT_ID')

        if not user_pool_id or not client_id:
            print("Cognito environment variables not set.")
            return {
                'statusCode': 500,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'Internal server error: Cognito configuration missing'})
            }

        # Initialize Cognito client
        cognito_client = boto3.client('cognito-idp')

        # Determine authentication method based on input
        if cpf and not email and not password:
            # CPF-only authentication for User group
            return authenticate_with_cpf(cognito_client, user_pool_id, client_id, cpf)
        elif email and password:
            # Email/password authentication for Admin group
            return authenticate_with_email_password(cognito_client, user_pool_id, client_id, email, password)
        else:
            return {
                'statusCode': 400,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'Invalid request. Provide either CPF only or email+password.'})
            }

    except json.JSONDecodeError:
        print(f"JSON Decode Error: {event.get('body', '')}")
        return {
            'statusCode': 400,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'message': 'Invalid JSON in request body'})
        }
    except Exception as e:
        print(f"Unhandled error: {e}")
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'message': 'Internal server error'})
        }


def authenticate_with_cpf(cognito_client, user_pool_id: str, client_id: str, cpf: str) -> Dict[str, Any]:
    """
    Authenticate user using only CPF (for User group)
    """
    try:
        print(f"Searching for user with CPF: {cpf}")
        
        # Find user by custom:cpf attribute
        # Note: Cognito filter doesn't work well with custom attributes, so we'll list all users and filter locally
        response = cognito_client.list_users(
            UserPoolId=user_pool_id,
            Limit=60  # Maximum allowed by Cognito
        )
        all_users = response.get('Users', [])
        print(f"Retrieved {len(all_users)} users from Cognito")
        
        # Filter users by custom:cpf attribute
        users = []
        for user in all_users:
            user_attributes = {attr['Name']: attr['Value'] for attr in user['Attributes']}
            if user_attributes.get('custom:cpf') == cpf:
                users.append(user)
                break  # CPF should be unique, so we can break after finding the first match
        
        print(f"Found {len(users)} users with CPF {cpf}")

        if not users:
            print("No users found with this CPF")
            return {
                'statusCode': 401,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'Invalid CPF'})
            }

        # Get the username (email) from the first user
        username = users[0]['Username']
        user_attributes = {attr['Name']: attr['Value'] for attr in users[0]['Attributes']}
        print(f"Found user: {username}, attributes: {user_attributes}")
        
        # Check if user is in 'user' group
        user_groups = get_user_groups(cognito_client, username, user_pool_id)
        print(f"User groups: {user_groups}")

        if 'user' not in user_groups:
            print(f"User is not in 'user' group. Groups: {user_groups}")
            return {
                'statusCode': 403,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'CPF authentication is only for "user" group'})
            }

        print("Initiating user password auth flow...")
        try:
            # For user group, use user password auth with a temporary password
            # First, set a permanent password for the user
            cognito_client.admin_set_user_password(
                UserPoolId=user_pool_id,
                Username=username,
                Password="TempPass123!",
                Permanent=True
            )
            print("User password set successfully")
            
            # Use user password auth flow
            auth_response = cognito_client.initiate_auth(
                ClientId=client_id,
                AuthFlow='USER_PASSWORD_AUTH',
                AuthParameters={
                    'USERNAME': username,
                    'PASSWORD': "TempPass123!"
                }
            )
            print(f"Auth response: {auth_response}")

            # If we get here, the user exists and is in User group
            if 'AuthenticationResult' in auth_response:
                auth_result = auth_response['AuthenticationResult']
                
                return {
                    'statusCode': 200,
                    'headers': {'Access-Control-Allow-Origin': '*'},
                    'body': json.dumps({
                        'access_token': auth_result.get('AccessToken'),
                        'id_token': auth_result.get('IdToken'),
                        'refresh_token': auth_result.get('RefreshToken'),
                        'token_type': auth_result.get('TokenType', 'Bearer'),
                        'expires_in': auth_result.get('ExpiresIn', 3600),
                        'auth_method': 'cpf'
                    })
                }
            else:
                return {
                    'statusCode': 401,
                    'headers': {'Access-Control-Allow-Origin': '*'},
                    'body': json.dumps({'message': 'CPF not found or user not in User group'})
                }
        except ClientError as auth_error:
            error_code = auth_error.response['Error']['Code']
            print(f"Auth error: {auth_error}")
            return {
                'statusCode': 401,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'Authentication failed. Please try again.'})
            }

    except ClientError as e:
        error_code = e.response['Error']['Code']
        print(f"Cognito error: {e}")
        if error_code == 'UserNotFoundException':
            return {
                'statusCode': 404,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'CPF not found'})
            }
        elif error_code == 'NotAuthorizedException':
            return {
                'statusCode': 401,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'Invalid CPF or user not in User group'})
            }
        else:
            return {
                'statusCode': 500,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'Authentication service error'})
            }


def get_user_groups(cognito_client, username: str, user_pool_id: str) -> list:
    """
    Get the groups that a user belongs to
    """
    try:
        response = cognito_client.admin_list_groups_for_user(
            Username=username,
            UserPoolId=user_pool_id
        )
        return [group['GroupName'] for group in response.get('Groups', [])]
    except Exception as e:
        print(f"Error getting user groups for {username}: {e}")
        return []


def authenticate_with_email_password(cognito_client, user_pool_id: str, client_id: str, email: str, password: str) -> Dict[str, Any]:
    """
    Authenticate user using email and password (for Admin group)
    """
    try:
        # Authenticate user with Cognito
        response = cognito_client.admin_initiate_auth(
            UserPoolId=user_pool_id,
            ClientId=client_id,
            AuthFlow='ADMIN_NO_SRP_AUTH',
            AuthParameters={
                'USERNAME': email,
                'PASSWORD': password
            }
        )

        # Check if authentication was successful
        if 'AuthenticationResult' in response:
            auth_result = response['AuthenticationResult']
            
            return {
                'statusCode': 200,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({
                    'access_token': auth_result.get('AccessToken'),
                    'id_token': auth_result.get('IdToken'),
                    'refresh_token': auth_result.get('RefreshToken'),
                    'token_type': auth_result.get('TokenType', 'Bearer'),
                    'expires_in': auth_result.get('ExpiresIn', 3600),
                    'auth_method': 'email_password'
                })
            }
        else:
            return {
                'statusCode': 401,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'Authentication failed'})
            }

    except ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code == 'NotAuthorizedException':
            return {
                'statusCode': 401,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'Invalid credentials'})
            }
        elif error_code == 'UserNotFoundException':
            return {
                'statusCode': 404,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'User not found'})
            }
        elif error_code == 'UserNotConfirmedException':
            return {
                'statusCode': 400,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'User not confirmed. Please check your email for confirmation link.'})
            }
        elif error_code == 'PasswordResetRequiredException':
            return {
                'statusCode': 400,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'Password reset required. Please reset your password.'})
            }
        else:
            print(f"Cognito error: {e}")
            return {
                'statusCode': 500,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'Authentication service error'})
            }