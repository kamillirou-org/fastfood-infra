import json
import os
import boto3
from botocore.exceptions import ClientError
from typing import Dict, Any

def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Cognito Custom Authentication Challenge Lambda
    Handles CPF-only authentication for User group
    """
    print(f"Received event: {json.dumps(event)}")

    try:
        # Get the challenge name
        challenge_name = event.get('request', {}).get('challengeName')
        
        if challenge_name == 'CUSTOM_CHALLENGE':
            return handle_custom_challenge(event)
        else:
            # For other challenges, just pass through
            return event

    except Exception as e:
        print(f"Error in custom challenge: {e}")
        return event


def handle_custom_challenge(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle custom challenge for CPF authentication
    """
    try:
        # Get user attributes
        user_attributes = event.get('request', {}).get('userAttributes', {})
        cpf = user_attributes.get('custom:cpf', '')
        
        # Get the challenge answer (CPF from the request)
        challenge_answer = event.get('request', {}).get('challengeAnswer', '')
        
        # Verify CPF matches
        if cpf and cpf == challenge_answer:
            # CPF matches, create tokens
            event['response']['answerCorrect'] = True
            event['response']['issueTokens'] = True
        else:
            # CPF doesn't match
            event['response']['answerCorrect'] = False
            event['response']['issueTokens'] = False
            
        return event

    except Exception as e:
        print(f"Error handling custom challenge: {e}")
        event['response']['answerCorrect'] = False
        event['response']['issueTokens'] = False
        return event
